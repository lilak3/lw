'''
Book.py
기능 설명: Book 클래스 구현

'''
class Book:
    def __init__(self, isbn, title, gn, author, publisher, price):
        self.isbn = isbn
        self.title = title
        self.gn = gn
        self.author = author
        self.publisher = publisher
        self.price = price

    def Write(self, fs):
        fs.write(self.isbn + ",")
        fs.write(self.title + ",")
        fs.write(str(self.gn) + ",")
        fs.write(self.author + ",")
        fs.write(self.publisher + ",")
        fs.write(str(self.price) + "\n")

    @staticmethod
    def LoadBook(fs):
        data = fs.readline()
        elems = data.split(",")

        if len(elems) < 6:
            return None
        
        isbn = elems[0]
        title = elems[1]
        gn = int(elems[2])
        author = elems[3]
        publisher = elems[4]

        return Book(isbn, title, gn, author, publisher)