'''
도서 관리 프로그램 (파일 입출력 포함)

- 도서 관리 프로그램은 콘솔 응용 프로그램이다.
- 응용에서는 사용자와 상호작용을 담당한다.
- 응용은 사용자에게 메뉴를 보여주고 선택한 메뉴를 수행하는 것을 반복한다.
- 메뉴에는 장르 추가, 도서 추가,도서 삭제, 도서 검색, 전체 도서 보기, 프로그램 종료가 있다.
- 장르 추가를 선택하면 추가할 장르 명을 입력받아 추가한다.
- 도서 추가를 선택하면 장르를 선택하고 도서 정보를 입력받아 추가한다.
- 도서는 ISBN(주요키), 도서명, 저자, 출판사, 가격 정보를 사용자로부터 입력받는다.
- 도서 삭제 기능에서는 도서의 ISBN을 사용자로부터 입력받아 삭제한다.
- 도서 검색 기능에서는 도서의 ISBN을 사용자로부터 입력받아 검색한다.
- 전체 보기에서는 전체 도서 정보를 출력한다.
- 프로그램 종료할 때 데이터를 파일에 저장하고 프로그램 시작할 때 로딩한다.

'''

from func import SelectMenu
from func import AddBook
from func import AddGenre
from func import FindBook
from func import RemoveBook
from func import ViewAll
from func import Save
from func import Load

def main():
    genres = list()
    books = list()
    Load(genres, books)

    while True:
        key = SelectMenu()

        if key == '0':
            break

        elif key == '1':
            AddGenre(genres)

        elif key == '2':
            AddBook(genres, books)

        elif key == '3':
            RemoveBook(books)

        elif key == '4':
            FindBook(books)

        elif key == '5':
            ViewAll(genres, books)

        else:
            print("잘못 선택하였습니다.")

        print("엔터를 누르세요.")
        input()

    Save(genres,books)
    print("프로그램을 종료합니다.")

if __name__ == '__main__':
    main()