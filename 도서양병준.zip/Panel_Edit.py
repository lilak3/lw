from tkinter import *
from tkinter.filedialog import askopenfilename

ENTRY_WIDTH = 200

class Panel_Edit_User():                                                                   #왼쪽 버튼 인터페이스 

    # 생성자
    def __init__(self, window, x, y):

        self.label_name = Label(window, text="이름 : ")
        self.label_name.place(x=x, y=y)

        self.label_phone = Label(window, text="전화번호 : ")        
        self.label_phone.place(x=x, y=y+25)

        self.label_gender = Label(window, text = "성별 : ")
        self.label_gender.place(x=x,y=y+50)

        self.label_registration = Label(window,text="관심사 : ")                        
        self.label_registration.place(x=x,y=y+75)



#인터페이스 생성

        self.entry_phone = Entry(window)
        self.entry_phone.place(x=x+60, y=y, width=ENTRY_WIDTH)

        self.entry_name = Entry(window)
        self.entry_name.place(x=x+60, y=y+25, width=ENTRY_WIDTH)


        self.RadioButton_gender = StringVar(window)
        self.gender_rb1 = Radiobutton(window, text="남",variable=self.RadioButton_gender,value="남")                       #남여 구별 버튼
        self.gender_rb2 = Radiobutton(window, text="여",variable=self.RadioButton_gender,value="여")
        self.gender_rb1.place(x=x+60,y=y+50)
        self.gender_rb2.place(x=x+140,y=y+50)
        self.RadioButton_registration = IntVar(window)
        self.registration_rb1= Radiobutton(window, text="운동",variable=self.RadioButton_registration,value="운동")        #관심사  운동 ,요리
        self.registration_rb2= Radiobutton(window, text="요리",variable=self.RadioButton_registration,value="요리")
        self.registration_rb1.place(x=x+60,y=y+75)
        self.registration_rb2.place(x=x+140,y=y+75)
        self.image_button = 0

        #속성값 회수
    def return_count(self):
        return self.image_button
    def get_phone(self):
        return self.entry_phone.get()
    def get_name(self):
        return self.entry_name.get()
    def get_gender(self):
        gender_text = self.RadioButton_gender.get()
        return gender_text
    def get_REG(self):
        reg_boolean = bool(self.RadioButton_registration.get())
        return reg_boolean
    def forget_regis(self):
        self.label_registration.place_forget()
        self.registration_rb1.place_forget()
        self.registration_rb2.place_forget()
    def self_return(self):
        return self


class Panel_Edit_Book():

    # 생성자
    def __init__(self, window, x, y):

        self.label_isbn = Label(window, text="도서 코드 : ")
        self.label_isbn.place(x=x, y=y)

        self.label_title = Label(window, text="책 제목 : ")
        self.label_title.place(x=x, y=y+25)

        self.label_author = Label(window, text="저자정보 : ")
        self.label_author.place(x=x, y=y+50)

        self.label_plac = Label(window, text="도서관 : ")
        self.label_plac.place(x=x, y=y+100)

 #생성자 빈칸 정의
        self.entry_isbn = Entry(window)
        self.entry_isbn.place(x=x+60, y=y, width=ENTRY_WIDTH)

        self.entry_title = Entry(window)
        self.entry_title.place(x=x+60, y=y+25, width=ENTRY_WIDTH)

        self.entry_author = Entry(window)
        self.entry_author.place(x=x+60, y=y+50, width=ENTRY_WIDTH)

        self.entry_plac = Entry(window)
        self.entry_plac.place(x=x+60, y=y+100, width=ENTRY_WIDTH)

    #도서 관련 값 리턴
    def get_isbn(self):
        return self.entry_isbn.get().rstrip()
    #예외처리
    def get_title(self):
        return self.entry_title.get().rstrip()
    def get_author(self):
        return self.entry_author.get().rstrip()
    def get_price(self):
        return self.entry_plac.get().rstrip()
# =======================================================================================