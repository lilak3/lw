from Window_Main import Window_Main

win = Window_Main()
